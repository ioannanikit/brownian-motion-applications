%% Άσκηση 3
mu = 0.1; sigma = 2; x0 = 100;
a = 95; b = 110;
t = 15; n = 1000; mc = 500;

success = 0; % Μετρητής περιπτώσεων που κέρδισε
dt = t/n;
time_vec = (0:dt:t)'; % Διάνυσμα χρόνου [0, 15]

for i = 1:mc
    % Δημιουργία κίνησης Brown (Gauss increments)
    dW = sqrt(dt) * randn(n, 1);
    W = [0; cumsum(dW)]; % Σωρευτικό άθροισμα για το μονοπάτι
    
    % Υπολογισμός τιμής μετοχής X(t)
    X = mu * time_vec + sigma * W + x0;
    
    % Εύρεση της πρώτης στιγμής που φτάνει σε ένα από τα δύο όρια
    idx_b = find(X >= b, 1); % Πρώτη φορά που X >= 110
    idx_a = find(X <= a, 1); % Πρώτη φορά που X <= 95
    
    % Έλεγχος αν "κέρδισε": Πρέπει να χτύπησε το b και
    % (είτε να μην χτύπησε ποτέ το a, είτε να χτύπησε το b νωρίτερα)
    if ~isempty(idx_b) && (isempty(idx_a) || idx_b < idx_a)
        success = success + 1;
    end
end

prob = success / mc;
fprintf('Πιθανότητα να κερδίσει ο επενδυτής: %.4f\n', prob);