%% Άσκηση 5
X0 = 1; lambda = 1.5; sigma = 0.5;
T = 2; m = 300; n = 500;
dt = T/n;

XT = zeros(m, 1); % Πίνακας για την αποθήκευση της τελικής τιμής X(T)

for j = 1:m
    X_current = X0;
    for i = 1:n
        % Παραγωγή του στοχαστικού βήματος dB ~ N(0, dt)
        dB = sqrt(dt) * randn;
        
        % Εφαρμογή της διακριτοποιημένης εξίσωσης
        X_next = X_current - lambda * X_current * dt + sigma * dB;
        
        % Ενημέρωση της τρέχουσας τιμής
        X_current = X_next;
    end
    XT(j) = X_current; % Αποθήκευση της τιμής στο χρόνο T
end

% Υπολογισμός Μέσης Τιμής και Διασποράς
mean_XT = mean(XT);
var_XT = var(XT);

% Θεωρητικές τιμές για επαλήθευση
theory_mean = X0 * exp(-lambda * T);
theory_var = (sigma^2 / (2 * lambda)) * (1 - exp(-2 * lambda * T));

fprintf('Monte Carlo -> Μέση Τιμή: %.4f, Διασπορά: %.4f\n', mean_XT, var_XT);
fprintf('Θεωρία      -> Μέση Τιμή: %.4f, Διασπορά: %.4f\n', theory_mean, theory_var);