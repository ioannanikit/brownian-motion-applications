%% Άσκηση 1
% Αλγόριθμοι Brownian Motion
function Bt = brown_rw(t, n, p, S0)
if nargin < 3, p = 0.5; end
if nargin < 4, S0 = 0; end
dt = t / n;
rand_vec = rand(n,1) < p;
Xi = sqrt(dt) * (2*rand_vec - 1);
Bt = S0 + sum(Xi);
end

function Bt = brown_gauss(t, n, S0)
if nargin < 3, S0 = 0; end
dt = t / n;
increments = sqrt(dt) * randn(n,1);
Bt = S0 + sum(increments);
end

function path = brown_path(t, n, S0)
if nargin < 3, S0 = 0; end
dt = t / n;
path = zeros(n+1,1); path(1) = S0;
for i=1:n
    path(i+1) = path(i) + sqrt(dt)*randn;
end
end

%% Monte Carlo Test t=1, n=1000, mc=10000
t=1; n=1000; mc=10000;
B_rw = arrayfun(@(i) brown_rw(t,n), 1:mc);
B_gauss = arrayfun(@(i) brown_gauss(t,n), 1:mc);
p_rw = mean(abs(B_rw)<0.5);
p_gauss = mean(abs(B_gauss)<0.5);
theory = normcdf(0.5)-normcdf(-0.5);
fprintf('Θεωρία: %.4f\nRW: %.4f\nGAUSS: %.4f\n', theory, p_rw, p_gauss);
