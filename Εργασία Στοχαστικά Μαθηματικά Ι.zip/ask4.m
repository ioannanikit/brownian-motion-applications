%% Άσκηση 4
T = 3; n = 500; mc = 100;
dt = T/n;

LHS = zeros(mc, 1); % Αριστερό μέλος
RHS = zeros(mc, 1); % Δεξί μέλος

for j = 1:mc
    % Δημιουργία μονοπατιού Brown
    dW = sqrt(dt) * randn(n, 1);
    W = [0; cumsum(dW)]; 
    
    % Υπολογισμός Αριστερού Μέλους (Ολοκλήρωμα Ito)
    % sum( B(t_i-1) * delta_B )
    integral_sum = 0;
    for i = 1:n
        integral_sum = integral_sum + W(i) * dW(i);
    end
    LHS(j) = integral_sum;
    
    % Υπολογισμός Δεξιού Μέλους
    RHS(j) = 0.5 * W(end)^2 - T/2;
end

% Στατιστικά στοιχεία
fprintf('Αριστερό Μέλος (LHS) -> Μέση Τιμή: %.4f, Διασπορά: %.4f\n', mean(LHS), var(LHS));
fprintf('Δεξί Μέλος (RHS)     -> Μέση Τιμή: %.4f, Διασπορά: %.4f\n', mean(RHS), var(RHS));