%% Άσκηση 2 
x = 0:10;
y = 0:10;
[X, Y] = meshgrid(x, y);

% 1. Υπολογισμός σταθεράς c
f_raw = 0.2*X + 1.5*Y; 
c = 1 / sum(f_raw(:));
f = c * f_raw; % Πραγματική f(x,y)

% 2. Περιθώριες Κατανομές
f_x = sum(f, 1); % Περιθώρια ως προς x (άθροισμα στη στήλη y)
f_y = sum(f, 2); % Περιθώρια ως προς y (άθροισμα στη γραμμή x)

% 3. Μέση Τιμή E(X)
EX = sum(x .* f_x);

% 4. Δεσμευμένη Μέση Τιμή E(X|Y)
% Για κάθε y, η E(X|Y=y) = sum(x * f(x,y) / f_y(y))
EX_given_Y = zeros(size(y));
for j = 1:length(y)
    EX_given_Y(j) = sum(x .* (f(j,:) / f_y(j)));
end

% 5. Επαλήθευση E(E(X|Y))
E_EX_Y = sum(EX_given_Y' .* f_y);

% Εμφάνιση αποτελεσμάτων
fprintf('Σταθερά c: %.8f\n', c);
fprintf('E(X): %.4f\n', EX);
fprintf('E(E(X|Y)): %.4f\n', E_EX_Y);
