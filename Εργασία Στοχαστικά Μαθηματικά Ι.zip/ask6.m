%% Άσκηση 6
S_t = 100;    % Τρέχουσα τιμή μετοχής S(t)
K = 105;      % Τιμή εξάσκησης (Strike price)
r = 0.05;     % Risk-free επιτόκιο 5%
sigma = 0.2; % Μεταβλητότητα (Volatility) 20%
T = 1;        % Χρόνος λήξης (Maturity time) σε έτη
t = 0;        % Τρέχουσα χρονική στιγμή

% 2. Υπολογισμός υπολειπόμενου χρόνου (Time to maturity)
dt = T - t;

% 3. Υπολογισμός των d1 και d2
d1 = (log(S_t / K) + (r + (sigma^2) / 2) * dt) / (sigma * sqrt(dt));
d2 = d1 - sigma * sqrt(dt);

% 4. Υπολογισμός της τιμής του Call Option c(t)
c_t = S_t * normcdf(d1) - K * exp(-r * dt) * normcdf(d2);

% Εμφάνιση αποτελέσματος
fprintf('Η τιμή του Call Option c(t) είναι: %.4f\n', c_t);